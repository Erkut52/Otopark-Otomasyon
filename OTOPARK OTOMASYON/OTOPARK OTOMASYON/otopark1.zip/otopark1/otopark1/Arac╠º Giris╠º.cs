﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otopark1
{
    public partial class Araç_Giriş : Form
    {
        public Araç_Giriş()
        {
            InitializeComponent();
        }

        SqlConnection bağlanti = new SqlConnection("Data Source=DESKTOP-OQUGLRJ\\SQLEXPRESS;Initial Catalog=araç_otopark;Integrated Security=True;Encrypt=False");

        private void Araç_Giriş_Load(object sender, EventArgs e)
        {
            BoşAraçlar();
            Marka();
            
        }

        private void Marka()
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("SELECT marka  from markabilgiler ", bağlanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboMarka.Items.Add(read["marka"].ToString());
            }
            bağlanti.Close();
        }

        private void BoşAraçlar()
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("SELECT * FROM aracdurumu WHERE durumu='BOŞ'", bağlanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboPark.Items.Add(read["parkyeri"].ToString());
            }
            bağlanti.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bağlanti.Open();
            SqlCommand komut =new SqlCommand("insert into araç_otopark_kaydı(tc,ad,soyad,telefon,email,plaka,marka,seri,renk,parkyeri,tarih) values(@tc,@ad,@soyad,@telefon,@email,@plaka,@marka,@seri,@renk,@parkyeri,@tarih)", bağlanti);
            komut.Parameters.AddWithValue("@tc", txtTc.Text);
            komut.Parameters.AddWithValue("@ad", txtAd.Text);
            komut.Parameters.AddWithValue("@soyad",TxtSoyad.Text);
            komut.Parameters.AddWithValue("@telefon", txtTel.Text);
            komut.Parameters.AddWithValue("@email",TxtMail.Text);
            komut.Parameters.AddWithValue("@plaka",txtPlaka.Text);
            komut.Parameters.AddWithValue("@marka",comboMarka.Text);
            komut.Parameters.AddWithValue("@seri", ComboSeri.Text);
            komut.Parameters.AddWithValue("@renk",txtRenk.Text);
            komut.Parameters.AddWithValue("@parkyeri", comboPark.Text);
            komut.Parameters.AddWithValue("@tarih", DateTime.Now.ToString());

            komut.ExecuteNonQuery();


            SqlCommand komut2 = new SqlCommand("update aracdurumu set durumu='DOLU' where parkyeri='" + comboPark.SelectedItem + "'",bağlanti);
            komut2.ExecuteNonQuery();
            bağlanti.Close();


            
            MessageBox.Show("Araç Kaydı Oluşturuldu", "Kayıt");
            comboPark.Items.Clear();
            BoşAraçlar();
            comboMarka.Items.Clear();
            Marka();
            ComboSeri.Items.Clear();
            foreach (Control item in groupBox1.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
            }
            foreach (Control item in groupBox2.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
            }
            foreach (Control item in groupBox2.Controls)
            {
                if (item is ComboBox)
                {
                    item.Text = "";
                }
            }

        }

        private void btnMarka_Click(object sender, EventArgs e)
        {
            frmMarka marka = new frmMarka();
            marka.ShowDialog();
        }

        private void btnSeri_Click(object sender, EventArgs e)
        {
            frmSERİ seri = new frmSERİ();
            seri.ShowDialog();
        }

        private void comboMarka_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboSeri.Items.Clear();
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("SELECT marka,seri  FROM seribilgileri where marka='"+comboMarka.SelectedItem+"'" , bağlanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                ComboSeri.Items.Add(read["seri"].ToString());
            }
            bağlanti.Close();

        }

        private void ComboSeri_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
