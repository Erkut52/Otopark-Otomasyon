﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otopark1
{
    public partial class frmSatış : Form
    {
        public frmSatış()
        {
            InitializeComponent();
        }
        SqlConnection bağlanti = new SqlConnection("Data Source=DESKTOP-OQUGLRJ\\SQLEXPRESS;Initial Catalog=araç_otopark;Integrated Security=True;Encrypt=False");
        DataSet daset= new DataSet();
        private void frmSatış_Load(object sender, EventArgs e)
        {
            SatışListe();
            Hesapla();
        }

        private void Hesapla()
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("select sum(tutar) from satıs", bağlanti);
            label1.Text = "Toplam Tutar=" + komut.ExecuteScalar() + "TL";
            bağlanti.Close();
        }

        private void SatışListe()
        {
            bağlanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from satıs", bağlanti);
            adtr.Fill(daset, "satıs");
            dataGridView1.DataSource = daset.Tables["satıs"];
            bağlanti.Close();
        }
    }
}
