﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otopark1
{
    public partial class frmMarka : Form
    {
        public frmMarka()
        {
            InitializeComponent();
        }
        SqlConnection bağlanti = new SqlConnection("Data Source=DESKTOP-OQUGLRJ\\SQLEXPRESS;Initial Catalog=araç_otopark;Integrated Security=True;Encrypt=False");
        private void button1_Click(object sender, EventArgs e)
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("insert into markabilgiler(marka) values('"+textBox1.Text+"')", bağlanti);
            komut.ExecuteNonQuery();
            bağlanti.Close();
            MessageBox.Show("Marka Eklendi");
            textBox1.Clear();
        }
    }
}
