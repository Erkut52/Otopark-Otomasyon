﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otopark1
{
    public partial class anasayfa : Form
    {
        public anasayfa()
        {
            InitializeComponent();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Araç_Çıkış çıkış = new Araç_Çıkış();
            çıkış.ShowDialog();


        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Araç_Kaydı yer=new Araç_Kaydı();
            yer.ShowDialog();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Araç_Giriş kayıt = new Araç_Giriş();
            kayıt.ShowDialog();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            frmSatış satis =new frmSatış();
            satis.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            guna2HtmlLabel1.Text = DateTime.Now.ToString();
        }

        private void anasayfa_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
