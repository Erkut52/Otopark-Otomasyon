﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otopark1
{
    public partial class frmSERİ : Form
    {
        public frmSERİ()
        {
            InitializeComponent();
        }
        SqlConnection bağlanti = new SqlConnection("Data Source=DESKTOP-OQUGLRJ\\SQLEXPRESS;Initial Catalog=araç_otopark;Integrated Security=True;Encrypt=False");

        private void marka()
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("SELECT marka  FROM markabilgiler ", bağlanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboBox1.Items.Add(read["marka"].ToString());
            }
            bağlanti.Close();
        }
        private void frmSERİ_Load(object sender, EventArgs e)
        {
            marka();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("insert into seribilgileri(marka,seri) values('" + comboBox1.Text + "','"+textBox1.Text+"')", bağlanti);
            komut.ExecuteNonQuery();
            bağlanti.Close();
            MessageBox.Show("Markaya bağlı seri eklendi");
            textBox1.Clear();
            comboBox1.Text = "";
            comboBox1.Items.Clear();
            marka();
        }
    }
}
