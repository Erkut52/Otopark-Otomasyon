﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using System.Data.SqlClient;


namespace otopark1
{
    public partial class Araç_Kaydı : Form
    {
        int toplamKapasite = 10; // Otoparkın toplam kapasitesi (örneğin 50)
        int doluYerSayisi = 0;   // Dolu park yerlerinin sayısı

        public Araç_Kaydı()
        {
            InitializeComponent();
        }

        SqlConnection bağlanti = new SqlConnection("Data Source=DESKTOP-OQUGLRJ\\SQLEXPRESS;Initial Catalog=araç_otopark;Integrated Security=True;Encrypt=False");

        private void ShowDolulukOrani()
        {
            // Doluluk oranını hesapla
            double dolulukOrani = ((double)doluYerSayisi / toplamKapasite) * 100;
            labelDolulukOrani.Text = $"Otopark Doluluk Oranı: {dolulukOrani:F2}%";
        }

        private void Araç_Kaydı_Load(object sender, EventArgs e)
        {
            BoşParkYerleri();
            DoluParkYerleri();
            ShowDolulukOrani();

            // Veritabanı ile bağlantı kurma
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("select * from araç_otopark_kaydı", bağlanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                foreach (Control item in Controls)
                {
                    if (item is Button)
                    {
                        if (item.Text == read["parkyeri"].ToString())
                        {
                            item.Text = read["plaka"].ToString();
                        }
                    }
                }
            }
            bağlanti.Close();
        }

        private void TemizleParkYeriMetni()
        {
            foreach (Control item in Controls)
            {
                if (item is Button)
                {
                    item.Text = ""; // Butonun metnini temizler
                }
            }
        }

        private void DoluParkYerleri()
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("select * from aracdurumu", bağlanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                foreach (Control item in Controls)
                {
                    if (item is Button)
                    {
                        if (item.Text == read["parkyeri"].ToString() && read["durumu"].ToString() == "DOLU")
                        {
                            item.BackColor = Color.Red;
                            doluYerSayisi++; // Dolu yer sayısını artır
                        }
                    }
                }
            }
            bağlanti.Close();
        }

        private void BoşParkYerleri()
        {
            int sayac = 1;
            foreach (Control item in Controls)
            {
                if (item is Button)
                {
                    item.Text = "P-" + sayac;
                    item.Name = "P-" + sayac;
                    sayac++;
                }
            }
        }

        // Çıkış yapıldığında park yerini temizle
        private void CikisYap(string parkYeri)
        {
            // Park yerinin rengini eski haline getir (boş)
            foreach (Control item in Controls)
            {
                if (item is Button && item.Text == parkYeri)
                {
                    item.Text = ""; // Plakayı temizle
                    item.BackColor = Color.Gray; // Rengi gri yap (boş alan)
                }
            }

            // Veritabanındaki durumu güncelle (BOŞ yap)
            SqlCommand komut = new SqlCommand("UPDATE aracdurumu SET durumu='BOŞ' WHERE parkyeri=@parkyeri", bağlanti);
            komut.Parameters.AddWithValue("@parkyeri", parkYeri);

            bağlanti.Open();
            komut.ExecuteNonQuery();
            bağlanti.Close();

            // Doluluk oranını güncelle
            ShowDolulukOrani();
        }

        // Bu metodu çıkış yapıldığı zaman çağırabilirsiniz. Örneğin bir butona tıklayınca:
        private void guna2Button4_Click(object sender, EventArgs e)
        {
            string parkYeri = "P-1"; // Çıkış yapılan park yeri örneği, bunu değiştirebilirsiniz.
            CikisYap(parkYeri);
        }

        private void guna2HtmlLabel2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
