﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace otopark1
{
    public partial class Araç_Çıkış : Form
    {
        public Araç_Çıkış()
        {
            InitializeComponent();
        }
        SqlConnection bağlanti = new SqlConnection("Data Source=DESKTOP-OQUGLRJ\\SQLEXPRESS;Initial Catalog=araç_otopark;Integrated Security=True;Encrypt=False");
        private void Araç_Çıkış_Load(object sender, EventArgs e)
        {
            DoluYerler();
            Plakalar();
            timer1.Enabled = true;
        }

        private void Plakalar()
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("select *from araç_otopark_kaydı ", bağlanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboPLAKA.Items.Add(read["plaka"].ToString());
            }
            bağlanti.Close();
        }
        


        private void DoluYerler()
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("select *from aracdurumu where durumu='DOLU'", bağlanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                ComboParkYeri1.Items.Add(read["parkyeri"].ToString());
            }
            bağlanti.Close();
        }
        


        private void comboPLAKA_SelectedIndexChanged(object sender, EventArgs e)
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("select *from araç_otopark_kaydı where plaka='" +comboPLAKA.SelectedItem+"'", bağlanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                TXTyer.Text = read["parkyeri"].ToString();
            }
            bağlanti.Close();
        }

        private void ComboParkYeri1_SelectedIndexChanged(object sender, EventArgs e)
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("select *from araç_otopark_kaydı where parkyeri='" + ComboParkYeri1.SelectedItem + "'", bağlanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                txtyer2.Text = read["parkyeri"].ToString();
                txtTC.Text = read["tc"].ToString();
                TXTad.Text = read["ad"].ToString();
                txtSoyad.Text = read["soyad"].ToString();
                txtMarka.Text = read["marka"].ToString();
                txtSeri.Text = read["seri"].ToString();
                txtPlaka.Text = read["plaka"].ToString();
                lblGeliş.Text = read["tarih"].ToString();
            }
            bağlanti.Close();
            DateTime geliş, çıkış;
            geliş = DateTime.Parse(lblGeliş.Text);
            çıkış = DateTime.Parse(lblÇıkış.Text);
            TimeSpan fark;
            fark = çıkış - geliş;
            lblSüre.Text = fark.TotalHours.ToString("0.00");
            
            
           lblToplamTutar.Text = (double.Parse(lblSüre.Text) * (0.75)).ToString("0.00");;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblÇıkış.Text=DateTime.Now.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bağlanti.Open();
            SqlCommand komut = new SqlCommand("delete from araç_otopark_kaydı where plaka='"+txtPlaka.Text+ "'", bağlanti);
            komut.ExecuteNonQuery();
            SqlCommand komut2 = new SqlCommand("update  aracdurumu set durumu='BOŞ' where parkyeri='" + txtyer2.Text + "'", bağlanti);
            komut2.ExecuteNonQuery();
            SqlCommand komut3 = new SqlCommand("insert into satıs(parkyeri,plaka,geliş_tarihi,çıkış_tarihi,süre,tutar) values(@parkyeri,@plaka,@geliş_tarihi,@çıkış_tarihi,@süre,@tutar)", bağlanti);
            komut3.Parameters.AddWithValue("@parkyeri", txtyer2.Text);
            komut3.Parameters.AddWithValue("@plaka", txtPlaka.Text);
            komut3.Parameters.AddWithValue("@geliş_tarihi", lblGeliş.Text);
            komut3.Parameters.AddWithValue("@çıkış_tarihi", lblÇıkış.Text);
            komut3.Parameters.AddWithValue("@süre", double.Parse(lblSüre.Text));
            komut3.Parameters.AddWithValue("@tutar", double.Parse(lblToplamTutar.Text));
            komut3.ExecuteNonQuery();

            bağlanti.Close();
            MessageBox.Show("Araç Çıkışı Yapıldı");
            foreach (Control item in groupBox2.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                    TXTyer.Text = "";
                    ComboParkYeri1.Text = "";
                    comboPLAKA.Text = ""; 
                        
                }
            }
            comboPLAKA.Items.Clear();
            ComboParkYeri1.Items.Clear();
            DoluYerler();
            Plakalar();
            


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
